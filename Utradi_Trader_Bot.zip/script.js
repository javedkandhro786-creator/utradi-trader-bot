
const signalOutput = document.getElementById('signal-output');
const getSignalBtn = document.getElementById('get-signal');
const themeToggleBtn = document.getElementById('theme-toggle');

getSignalBtn.addEventListener('click', () => {
    const directions = ['⬆️ BUY', '⬇️ SELL'];
    const signal = directions[Math.floor(Math.random() * directions.length)];
    signalOutput.textContent = `Signal: ${signal}`;
    signalOutput.style.color = signal.includes('BUY') ? 'green' : 'red';
});

themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
});
